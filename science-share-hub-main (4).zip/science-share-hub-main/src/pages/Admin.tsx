import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { Layout } from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Calendar } from '@/components/ui/calendar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { Reference, Profile } from '@/lib/supabase-types';
import { exportToDocx } from '@/lib/docx-export';
import { cn } from '@/lib/utils';
import { UserManagement } from '@/components/admin/UserManagement';
import { 
  Shield, 
  Download, 
  Search, 
  Loader2, 
  FileText,
  Users,
  BookOpen,
  FileJson,
  FileSpreadsheet,
  Trash2,
  FileType,
  CalendarIcon,
  X
} from 'lucide-react';
import { toast } from 'sonner';

export default function Admin() {
  const { user, isAdmin, isLoading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [references, setReferences] = useState<Reference[]>([]);
  const [profiles, setProfiles] = useState<Map<string, Profile>>(new Map());
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [exportFormat, setExportFormat] = useState('json');
  const [startDate, setStartDate] = useState<Date | undefined>(undefined);
  const [endDate, setEndDate] = useState<Date | undefined>(undefined);
  const [activeTab, setActiveTab] = useState('references');

  useEffect(() => {
    if (!authLoading) {
      if (!user) {
        navigate('/auth');
      } else if (!isAdmin) {
        navigate('/dashboard');
        toast.error('Accès réservé aux administrateurs');
      }
    }
  }, [user, isAdmin, authLoading, navigate]);

  useEffect(() => {
    if (isAdmin) {
      fetchData();
    }
  }, [isAdmin]);

  const fetchData = async () => {
    setIsLoading(true);
    try {
      // Fetch all references
      const { data: refsData } = await supabase
        .from('references')
        .select('*')
        .order('created_at', { ascending: false });

      const refs = (refsData as Reference[]) || [];
      setReferences(refs);

      // Fetch ALL profiles (not just those with references)
      const { data: profilesData } = await supabase
        .from('profiles')
        .select('*');

      const profilesMap = new Map<string, Profile>();
      (profilesData as Profile[] || []).forEach(p => {
        profilesMap.set(p.user_id, p);
      });
      setProfiles(profilesMap);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // Calculate reference counts per user
  const referenceCounts = new Map<string, number>();
  references.forEach(ref => {
    const count = referenceCounts.get(ref.user_id) || 0;
    referenceCounts.set(ref.user_id, count + 1);
  });

  const handleUserDeleted = (userId: string) => {
    setProfiles(prev => {
      const newMap = new Map(prev);
      newMap.delete(userId);
      return newMap;
    });
    setReferences(prev => prev.filter(ref => ref.user_id !== userId));
  };

  const handleUserAdded = () => {
    fetchData();
  };

  const filteredReferences = references.filter(ref => {
    // Text search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      const authorName = profiles.get(ref.user_id)?.full_name?.toLowerCase() || '';
      const matchesSearch = (
        ref.title.toLowerCase().includes(query) ||
        ref.journal?.toLowerCase().includes(query) ||
        authorName.includes(query)
      );
      if (!matchesSearch) return false;
    }
    
    // Date range filter
    const refDate = new Date(ref.created_at);
    if (startDate) {
      const start = new Date(startDate);
      start.setHours(0, 0, 0, 0);
      if (refDate < start) return false;
    }
    if (endDate) {
      const end = new Date(endDate);
      end.setHours(23, 59, 59, 999);
      if (refDate > end) return false;
    }
    
    return true;
  });

  const clearDateFilters = () => {
    setStartDate(undefined);
    setEndDate(undefined);
  };

  const documentTypeLabels: Record<string, string> = {
    article_scientifique: 'Article Scientifique',
    chapitre_livre: 'Chapitre de livre',
    ouvrage_scientifique: 'Ouvrage Scientifique',
    technologie: 'Technologie',
    innovation: 'Innovation',
  };

  const domaineLabels: Record<string, string> = {
    ST: 'Sciences et Technologies',
    SDS: 'Sciences de la Santé',
    LSH: 'Lettres et Sciences Humaines',
    SEG: 'Sciences Économiques et de Gestion',
    SJP: 'Sciences Juridiques et Politiques',
  };

  const handleDeleteReference = async (id: string) => {
    try {
      const { error } = await supabase
        .from('references')
        .delete()
        .eq('id', id);

      if (error) throw error;
      
      setReferences(prev => prev.filter(ref => ref.id !== id));
      toast.success('Publication supprimée avec succès');
    } catch (error) {
      console.error('Error deleting reference:', error);
      toast.error('Erreur lors de la suppression');
    }
  };

  const handleExport = () => {
    const profile = (userId: string) => profiles.get(userId);
    
    // Sort references by user name first
    const sortedRefs = [...filteredReferences].sort((a, b) => {
      const nameA = profile(a.user_id)?.full_name || 'ZZZ';
      const nameB = profile(b.user_id)?.full_name || 'ZZZ';
      return nameA.localeCompare(nameB);
    });
    
    // Format authors with their affiliations
    const formatAuthorsAffiliations = (authors: string[] | null, affiliations: string[] | null) => {
      if (!authors || authors.length === 0) return '';
      return authors.map((author, i) => {
        const aff = affiliations?.[i];
        return aff ? `${author} (${aff})` : author;
      }).join('; ');
    };
    
    const dataToExport = sortedRefs.map((ref, index) => {
      const userProfile = profile(ref.user_id);
      return {
        numero: index + 1,
        institution: 'Université Lédéa Bernard OUEDRAOGO',
        nom_prenoms: userProfile?.full_name || 'Inconnu',
        ufr_institut: userProfile?.ufr_institut || '',
        departement: userProfile?.departement || '',
        equipe_recherche: userProfile?.equipe_recherche || '',
        type_document: ref.document_type ? documentTypeLabels[ref.document_type] : 'Article Scientifique',
        titre: ref.title,
        auteur_principal: ref.is_principal_author ? 'Oui' : 'Non',
        revue_journal_editeur: ref.journal || '',
        annee_parution: ref.annee_parution || '',
        auteurs_affiliations: formatAuthorsAffiliations(ref.authors, ref.affiliations),
        domaine_technique: ref.domaine_technique ? domaineLabels[ref.domaine_technique] : '',
        statut_revue: ref.statut_revue || '',
        source_verification: ref.source_verification || (ref.doi ? `https://doi.org/${ref.doi}` : ''),
        resume: ref.abstract || '',
        pdf_url: ref.pdf_url || '',
        date_ajout: new Date(ref.created_at).toLocaleDateString('fr-FR'),
      };
    });

    let content: string;
    let mimeType: string;
    let extension: string;

    switch (exportFormat) {
      case 'csv':
        // CSV headers in French with proper formatting
        const csvHeaders = [
          'N°',
          'Institution',
          'Nom et Prénoms',
          'UFR/Institut',
          'Département',
          'Équipe de recherche',
          'Type de document',
          'Titre',
          'Auteur Principal',
          'Revue/Journal/Éditeur',
          'Année de parution',
          'Auteurs et Affiliations',
          'Domaine technique',
          'Statut revue',
          'Source de vérification',
          'Résumé',
          'Lien PDF',
          'Date d\'ajout'
        ];
        
        // Use semicolon as separator for better Excel compatibility
        const headerRow = csvHeaders.join(';');
        const rows = dataToExport.map(row => 
          Object.values(row).map(val => {
            if (val === null || val === undefined) return '';
            const strVal = String(val);
            // Escape quotes and wrap in quotes if contains special chars
            if (strVal.includes(';') || strVal.includes('"') || strVal.includes('\n')) {
              return `"${strVal.replace(/"/g, '""')}"`;
            }
            return strVal;
          }).join(';')
        );
        // Add BOM for UTF-8 Excel compatibility
        content = '\uFEFF' + [headerRow, ...rows].join('\n');
        mimeType = 'text/csv;charset=utf-8';
        extension = 'csv';
        break;
      
      default:
        content = JSON.stringify(dataToExport, null, 2);
        mimeType = 'application/json';
        extension = 'json';
    }

    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `rapport-publications-${new Date().toISOString().split('T')[0]}.${extension}`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success('Export réussi !');
  };

  const handleExportDocx = async () => {
    if (filteredReferences.length === 0) {
      toast.error('Aucune référence à exporter');
      return;
    }
    
    try {
      await exportToDocx({
        references: filteredReferences,
        profiles,
        isAdmin: true,
      });
      toast.success('Export DOCX réussi !');
    } catch (error) {
      console.error('Error exporting to DOCX:', error);
      toast.error('Erreur lors de l\'export DOCX');
    }
  };

  if (authLoading || isLoading) {
    return (
      <Layout>
        <div className="flex min-h-[60vh] items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </Layout>
    );
  }

  if (!isAdmin) {
    return null;
  }

  return (
    <Layout>
      <div className="container py-8">
        {/* Header */}
        <div className="mb-8 flex items-center gap-3">
          <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary">
            <Shield className="h-6 w-6 text-primary-foreground" />
          </div>
          <div>
            <h1 className="font-serif text-3xl font-bold">Administration</h1>
            <p className="text-muted-foreground">Gestion des références</p>
          </div>
        </div>

        {/* Stats */}
        <div className="mb-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <div className="card-elevated rounded-xl p-6">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                <BookOpen className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">
                  {(startDate || endDate) ? filteredReferences.length : references.length}
                </p>
                <p className="text-sm text-muted-foreground">
                  {(startDate || endDate) ? 'Réf. (période)' : 'Références totales'}
                </p>
                {(startDate || endDate) && (
                  <p className="text-xs text-muted-foreground">
                    sur {references.length} totales
                  </p>
                )}
              </div>
            </div>
          </div>
          
          <div className="card-elevated rounded-xl p-6">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-accent/20">
                <Users className="h-6 w-6 text-accent" />
              </div>
              <div>
                <p className="text-2xl font-bold">
                  {(startDate || endDate) 
                    ? new Set(filteredReferences.map(r => r.user_id)).size 
                    : profiles.size}
                </p>
                <p className="text-sm text-muted-foreground">
                  {(startDate || endDate) ? 'Contrib. (période)' : 'Contributeurs'}
                </p>
                {(startDate || endDate) && (
                  <p className="text-xs text-muted-foreground">
                    sur {profiles.size} totaux
                  </p>
                )}
              </div>
            </div>
          </div>
          
          <div className="card-elevated rounded-xl p-6">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-success/20">
                <FileText className="h-6 w-6 text-success" />
              </div>
              <div>
                <p className="text-2xl font-bold">
                  {(startDate || endDate) 
                    ? filteredReferences.filter(r => r.pdf_url).length 
                    : references.filter(r => r.pdf_url).length}
                </p>
                <p className="text-sm text-muted-foreground">
                  {(startDate || endDate) ? 'PDFs (période)' : 'PDFs'}
                </p>
                {(startDate || endDate) && (
                  <p className="text-xs text-muted-foreground">
                    sur {references.filter(r => r.pdf_url).length} totaux
                  </p>
                )}
              </div>
            </div>
          </div>
          
          <div className="card-elevated rounded-xl p-6">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/20">
                <CalendarIcon className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">
                  {(startDate || endDate) 
                    ? `${Math.round((filteredReferences.length / Math.max(references.length, 1)) * 100)}%`
                    : new Date().getFullYear()}
                </p>
                <p className="text-sm text-muted-foreground">
                  {(startDate || endDate) ? 'Part du total' : 'Année en cours'}
                </p>
                {(startDate || endDate) && startDate && endDate && (
                  <p className="text-xs text-muted-foreground">
                    {format(startDate, "dd/MM")} - {format(endDate, "dd/MM")}
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Tabs for References and Users */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full max-w-md grid-cols-2">
            <TabsTrigger value="references" className="flex items-center gap-2">
              <BookOpen className="h-4 w-4" />
              Publications
            </TabsTrigger>
            <TabsTrigger value="users" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              Utilisateurs
            </TabsTrigger>
          </TabsList>

          <TabsContent value="references" className="space-y-6">
            {/* Toolbar */}
            <div className="space-y-4">
          {/* Search and Date Filters */}
          <div className="flex flex-col gap-4 lg:flex-row lg:items-center">
            <div className="relative max-w-md flex-1">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Rechercher..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            
            {/* Date Range Filters */}
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-sm text-muted-foreground">Période :</span>
              
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-[160px] justify-start text-left font-normal",
                      !startDate && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {startDate ? format(startDate, "dd/MM/yyyy") : "Date début"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={startDate}
                    onSelect={setStartDate}
                    initialFocus
                    locale={fr}
                    className={cn("p-3 pointer-events-auto")}
                  />
                </PopoverContent>
              </Popover>
              
              <span className="text-sm text-muted-foreground">au</span>
              
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-[160px] justify-start text-left font-normal",
                      !endDate && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {endDate ? format(endDate, "dd/MM/yyyy") : "Date fin"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={endDate}
                    onSelect={setEndDate}
                    initialFocus
                    locale={fr}
                    className={cn("p-3 pointer-events-auto")}
                  />
                </PopoverContent>
              </Popover>
              
              {(startDate || endDate) && (
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={clearDateFilters}
                  className="h-9 w-9"
                >
                  <X className="h-4 w-4" />
                </Button>
              )}
            </div>
          </div>
          
          {/* Export Controls */}
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="text-sm text-muted-foreground">
              {filteredReferences.length} référence(s) sélectionnée(s)
              {(startDate || endDate) && (
                <span className="ml-2 text-primary">
                  (filtrées par période)
                </span>
              )}
            </div>
            
            <div className="flex flex-wrap items-center gap-2">
              <Select value={exportFormat} onValueChange={setExportFormat}>
                <SelectTrigger className="w-[120px]">
                  <SelectValue placeholder="Format" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="json">
                    <div className="flex items-center gap-2">
                      <FileJson className="h-4 w-4" />
                      JSON
                    </div>
                  </SelectItem>
                  <SelectItem value="csv">
                    <div className="flex items-center gap-2">
                      <FileSpreadsheet className="h-4 w-4" />
                      CSV
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
              
              <Button onClick={handleExport} disabled={filteredReferences.length === 0}>
                <Download className="mr-2 h-4 w-4" />
                {exportFormat.toUpperCase()}
              </Button>
              
              <Button variant="outline" onClick={handleExportDocx} disabled={filteredReferences.length === 0}>
                <FileType className="mr-2 h-4 w-4" />
                DOCX
              </Button>
            </div>
          </div>
        </div>

        {/* Table */}
        <div className="card-elevated overflow-hidden rounded-xl">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Titre</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Domaine</TableHead>
                <TableHead>Contributeur</TableHead>
                <TableHead>Année</TableHead>
                <TableHead>PDF</TableHead>
                <TableHead className="w-[80px]">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredReferences.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="py-8 text-center text-muted-foreground">
                    Aucune référence trouvée
                  </TableCell>
                </TableRow>
              ) : (
                filteredReferences.map(ref => (
                  <TableRow key={ref.id}>
                    <TableCell className="max-w-[250px]">
                      <p className="line-clamp-2 font-medium">{ref.title}</p>
                      {ref.journal && (
                        <p className="text-xs text-muted-foreground">{ref.journal}</p>
                      )}
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className="text-xs">
                        {ref.document_type ? documentTypeLabels[ref.document_type] : 'Article'}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {ref.domaine_technique ? (
                        <Badge variant="secondary">{ref.domaine_technique}</Badge>
                      ) : (
                        <span className="text-muted-foreground">-</span>
                      )}
                    </TableCell>
                    <TableCell>
                      <div>
                        <p className="font-medium">{profiles.get(ref.user_id)?.full_name || 'Inconnu'}</p>
                        {profiles.get(ref.user_id)?.departement && (
                          <p className="text-xs text-muted-foreground">{profiles.get(ref.user_id)?.departement}</p>
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {ref.annee_parution || new Date(ref.created_at).getFullYear()}
                    </TableCell>
                    <TableCell>
                      {ref.pdf_url ? (
                        <a
                          href={ref.pdf_url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex h-8 w-8 items-center justify-center rounded-md hover:bg-muted"
                        >
                          <FileText className="h-4 w-4 text-primary" />
                        </a>
                      ) : (
                        <span className="text-muted-foreground">-</span>
                      )}
                    </TableCell>
                    <TableCell>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:bg-destructive/10">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Supprimer la publication ?</AlertDialogTitle>
                            <AlertDialogDescription>
                              Cette action est irréversible. La publication "{ref.title.slice(0, 50)}..." 
                              de {profiles.get(ref.user_id)?.full_name || 'Inconnu'} sera définitivement supprimée.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Annuler</AlertDialogCancel>
                            <AlertDialogAction
                              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                              onClick={() => handleDeleteReference(ref.id)}
                            >
                              Supprimer
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
          </TabsContent>

          <TabsContent value="users">
            <UserManagement
              profiles={profiles}
              onUserDeleted={handleUserDeleted}
              onUserAdded={handleUserAdded}
              referenceCounts={referenceCounts}
            />
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
}
